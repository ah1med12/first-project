/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecommercesystem;

/**
 *
 * @author hp
 */
public class ElectronicProduct extends Product {
    private String brand;
    private int warrantyPeriod;
    
    public ElectronicProduct(int productId,String name,float price,String brand,int warrantyPriod){
        super(productId,name,price);
        this.brand = brand;
        this.warrantyPeriod = Math.abs(warrantyPeriod);
    }
    public void setBrand(String brand){
        this.brand = brand;
    }
    public String getBrand(){
        return brand;
}
    public void setWarrantyPeriod(int warrantyPriod){
        this.warrantyPeriod = Math.abs(warrantyPriod);
    }
    public int getWarrantyPeriod(){
        return warrantyPeriod;
    }    

}
