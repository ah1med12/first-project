/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecommercesystem;

/**
 *
 * @author hp
 */
public class Customer extends Product{
      private int customerId;
    private String name;
    private String address;
    
    public Customer(int customerId,String name ,String address){
        this.customerId = Math.abs(customerId);
        this.name = name;
        this.address = address;   
    }
    public void setCustomerId(int customerId){
        this.customerId = Math.abs(customerId);
    }
    public int getCustomerId(){
        return customerId;
    }
    public void setname(String name){
        
        this.name = name;
    }
    public String getname(){
        return name;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public String getAddress(){
        return address;
    }    

}
