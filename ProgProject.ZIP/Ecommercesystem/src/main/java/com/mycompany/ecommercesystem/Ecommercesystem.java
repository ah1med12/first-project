/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ecommercesystem;

import java.util.Scanner;

/**
 *
 * @author hp
 */
public class Ecommercesystem {
         /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
      // Create an electronic product
    ElectronicProduct electronicProduct = new ElectronicProduct(1, "Smartphone", 12500.90f, "Samsung", 2);

    // Create a clothing product
    ClothingProduct clothingProduct = new ClothingProduct(2, "T-shirt", 19.99f, "Medium", "Cotton");

    // Create a book product
    BookProduct bookProduct = new BookProduct(3, "OOP", 39.99f, "O'Reilly", "X Publications");

    // Create a customer
        System.out.println("Welcome to the E-Commerce System!");  
        System.out.println("Enter your customer ID: ");
    int customerId = sc.nextInt();
        System.out.println("Enter your name: ");
    String name = sc.next();
        System.out.println("Enter your address: ");
    String address = sc.next();
    Customer customer = new Customer(customerId, name, address);

    // Create a shopping cart for the customer
    System.out.print("How many products do you want to order? ");
    int nProducts = sc.nextInt();
Cart cart = new Cart(customer.getCustomerId(), nProducts);

    // Add products to the cart
    for (int i = 0; i < nProducts; i++) {
         System.out.println("Which product would you like to add? 1- Smartphone 2- T-shirt 3- OOP");
        int choice = sc.nextInt();
            switch (choice) {
                case 1 -> cart.addProduct(i,electronicProduct );
                case 2 -> cart.addProduct(i,  clothingProduct);
                case 3 -> cart.addProduct(i, bookProduct);
                default -> System.out.println("Invalid choice!");  
   } 
    }
     cart.calculatePrice();
 
     System.out.println("Your total is $" + cart.calculatePrice()+ ". Would you like to place the order? 1- Yes 2- No");
        int placeOrder = sc.nextInt();
        if (placeOrder == 1) {
          
            Order order = new Order(customer.getCustomerId(),1,cart.getProducts());
            System.out.println("Here's your order's summary:");
            order.printOrderInfo();
        } else {
            System.out.println("Order cancelled.");
        }
    }   
}
